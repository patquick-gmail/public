The server code is a node.js api on v24.13.0
The client is an html page with some javascript

For the server:

Set up node v24.13.0 (I use nvm)

Run npm install
Run npm start

Test with curl http://localhost:3000/status


For the client:

The page loads fine from the file system (I tested in Chrome and Edge)


I spent a couple of hours on the assignment directly but went into a rabbit hole using Claude and a few other AI tools before returning to Claude.
