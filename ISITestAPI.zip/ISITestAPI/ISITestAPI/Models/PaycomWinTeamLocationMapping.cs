﻿namespace ISITestAPI.Models
{
    public class PaycomWinTeamLocationMapping
    {
        //PaycomCat1,PaycomCat1Desc,PaycomCat2,PaycomCat2Desc,WinTeamLocationId,WinTeamLocationName,WinTeamPrimaryJobId

        public PaycomWinTeamLocationMapping() 
        { 
            Id=Guid.NewGuid();
            PaycomCat1 = string.Empty;
            PaycomCat1Desc = string.Empty;
            PaycomCat2 = string.Empty;
            PaycomCat2Desc = string.Empty;
            WinTeamLocationId = string.Empty;
            WinTeamLocationName = string.Empty;
            WinTeamPrimaryJobId = string.Empty;
        }

        public PaycomWinTeamLocationMapping(string csv)
        {
            if (!string.IsNullOrWhiteSpace(csv)) 
            { 
                string[] parts = csv.Split(',');

                Id = Guid.NewGuid();
                PaycomCat1 = parts[0];
                PaycomCat1Desc = parts[1];
                PaycomCat2 = parts[2];
                PaycomCat2Desc = parts[3];
                WinTeamLocationId = parts[4];
                WinTeamLocationName = parts[5];
                WinTeamPrimaryJobId = parts[6];            
            }

            else
            {
                Id = Guid.NewGuid();
                PaycomCat1 = string.Empty;
                PaycomCat1Desc = string.Empty;
                PaycomCat2 = string.Empty;
                PaycomCat2Desc = string.Empty;
                WinTeamLocationId = string.Empty;
                WinTeamLocationName = string.Empty;
                WinTeamPrimaryJobId = string.Empty;
            }

        }

        public Guid Id { get; set; }
        public string PaycomCat1 { get; set; }
        public string PaycomCat1Desc { get; set; }
        public string PaycomCat2 { get; set; }
        public string PaycomCat2Desc { get; set; }
        public string WinTeamLocationId { get; set; }
        public string WinTeamLocationName { get; set; }
        public string WinTeamPrimaryJobId { get; set; }

    }
}
