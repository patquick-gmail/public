﻿namespace ISITestAPI.Models
{
    public class PaycomEmployee
    {
        public PaycomEmployee() 
        {
            PaycomGuid = Guid.NewGuid();

            annual_salary = 0.00;
            hourly_salary = 0.00;
            last_pay_rate = 0.00;
            rate_1 = 0.00;
            ss_number = 0;

            //annual_salary = String.Empty;
            //hourly_salary = String.Empty;
            //last_pay_rate = String.Empty;
            //rate_1 = String.Empty;
            //ss_number = String.Empty;

            actual_marital_status = String.Empty;
            actual_marital_status_description = String.Empty;
            birth_date = String.Empty;
            business_title = String.Empty;
            city = String.Empty;

            clocksequencenumber = 0;
            //clocksequencenumber = String.Empty;

            //department_code = String.Empty;
            department_code = 0;
            department_description = String.Empty;
            //eeoc_class = String.Empty;
            //eeoc_class = 0;
            eeoc_class_description = String.Empty;
            employee_added = String.Empty;
            employee_code = String.Empty;
            employee_gl_code = String.Empty;
            employee_name = String.Empty;
            employee_status = String.Empty;
            firstname = String.Empty;
            //fulltime_or_parttime = String.Empty;
            fulltime_or_parttime = 0;
            //gender = String.Empty;
            gender = 0;
            hire_date = String.Empty;
            labor_allocation_details = String.Empty;
            lastname = String.Empty;
            location = String.Empty;
            nickname = String.Empty;
            position_code = String.Empty;
            position_family = String.Empty;
            position_family_code = String.Empty;
            position_family_name = String.Empty;
            position_id = String.Empty;
            position_seat_number = String.Empty;
            position_seat_title = String.Empty;
            position_title = String.Empty;
            //primary_phone = String.Empty;
            primary_phone = 0;
            //primary_phone_type = String.Empty;
            primary_phone_type = 0;
            
            ////secondary_phone = String.Empty;
            //secondary_phone = 0;
            ////secondary_phone_type = String.Empty;
            //secondary_phone_type = 0;
            
            state = String.Empty;
            street = String.Empty;
            supervisor_primary = String.Empty;
            //supervisor_primary_code = String.Empty;
            termination_reason = String.Empty;
            termination_type = String.Empty;
            termination_date = String.Empty;
            //zipcode = String.Empty;
            //zipcode = 0;
            //cat1 = String.Empty;
            cat1 = 0;
            cat1desc = String.Empty;
            cat2 = String.Empty;            
            cat2desc = String.Empty;
            //companyLocationId = String.Empty;
            companyLocationId = 0;
        }

        public Guid PaycomGuid { get; set; }

        public double annual_salary { get; set; }
        public double hourly_salary { get; set; }
        public double last_pay_rate { get; set; }
        public double rate_1 { get; set; }
        public long ss_number { get; set; }


        //public string annual_salary { get; set; }
        //public string hourly_salary { get; set; }
        //public string last_pay_rate { get; set; }
        //public string rate_1 { get; set; }
        //public string ss_number { get; set; }

        public string actual_marital_status { get; set; }
        public string actual_marital_status_description { get; set; }
        public string birth_date { get; set; }
        public string business_title { get; set; }
        public string city { get; set; }
        //public string clocksequencenumber { get; set; }
        public long clocksequencenumber { get; set; }

        //public string department_code { get; set; }
        public long department_code { get; set; }

        public string department_description { get; set; }
        //public string eeoc_class { get; set; }
        //public long eeoc_class { get; set; }

        public string eeoc_class_description { get; set; }
        public string employee_added { get; set; }
        public string employee_code { get; set; }
        public string employee_gl_code { get; set; }
        public string employee_name { get; set; }
        public string employee_status { get; set; }
        public string firstname { get; set; }

        //public string fulltime_or_parttime { get; set; }
        public int fulltime_or_parttime { get; set; }
        
        //public string gender { get; set; }
        public int gender { get; set; }

        public string hire_date { get; set; }
        public string labor_allocation_details { get; set; }
        public string lastname { get; set; }
        public string location { get; set; }
        public string nickname { get; set; }
        public string position_code { get; set; }
        public string position_family { get; set; }
        public string position_family_code { get; set; }
        public string position_family_name { get; set; }
        public string position_id { get; set; }
        public string position_seat_number { get; set; }
        public string position_seat_title { get; set; }
        public string position_title { get; set; }

        //public string primary_phone { get; set; }
        public long primary_phone { get; set; }
        //public string primary_phone_type { get; set; }
        public long primary_phone_type { get; set; }

        //public string secondary_phone { get; set; }
        //public long secondary_phone { get; set; }
        //public string secondary_phone_type { get; set; }
        //public long secondary_phone_type { get; set; }


        public string state { get; set; }
        public string street { get; set; }
        public string supervisor_primary { get; set; }
        //public string supervisor_primary_code { get; set; }
        public string termination_reason { get; set; }
        public string termination_type { get; set; }
        public string termination_date { get; set; }

        //public string zipcode { get; set; }
        //public int zipcode { get; set; }

        //public string cat1 { get; set; }
        public int cat1 { get; set; }

        public string cat1desc { get; set; }

        public string cat2 { get; set; }
        
        public string cat2desc { get; set; }

        //public string companyLocationId { get; set; }
        public long companyLocationId { get; set; }

    }
}
