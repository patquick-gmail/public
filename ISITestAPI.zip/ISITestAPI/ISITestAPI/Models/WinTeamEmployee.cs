﻿using System.Net.Http.Headers;
using System.Text;

namespace ISITestAPI.Models
{
    public class WinTeamEmployee
    {        
        public WinTeamEmployee() 
        {
            WinTeamGuid = Guid.NewGuid();
            AccrualTypeId = String.Empty;
            BirthDate = String.Empty;
            ClassificationId = String.Empty;
            CompanyNumber = String.Empty;
            DateAdded = String.Empty;
            DirectDepositThirdParty = String.Empty;
            EmailAddress = String.Empty;
            EmployeeId = String.Empty;
            EmployeeNumber = String.Empty;
            EthnicityId = String.Empty;
            FirstName = String.Empty;
            GenderId = String.Empty;
            HireDate = String.Empty;
            IsSupervisor = String.Empty;
            LastName = String.Empty;
            LocationId = String.Empty;
            MiddleName = String.Empty;
            Notes = String.Empty;
            PartialSSN = String.Empty;
            PayCheckDistributionType = String.Empty;
            PayCheckFrequencyId = String.Empty;
            PayRate = String.Empty;
            Phone1 = String.Empty;
            Phone1Description = String.Empty;
            Phone1Extension = String.Empty;
            Phone2 = String.Empty;
            Phone2Description = String.Empty;
            Phone2Extension = String.Empty;
            Phone3 = String.Empty;
            Phone3Description = String.Empty;
            Phone3Extension = String.Empty;
            PrimaryJob = String.Empty;
            SecurityLevel = String.Empty;
            StatusDescription = String.Empty;
            StatusId = String.Empty;
            SupervisorDescription = String.Empty;
            SupervisorId = String.Empty;
            Title = String.Empty;
            TitleId = String.Empty;
            TypeDescription = String.Empty;
            TypeId = String.Empty;
            UserName = String.Empty;

        }

        public Guid WinTeamGuid { get; set; }
        public string AccrualTypeId { get; set; }
        public string BirthDate { get; set; }
        public string ClassificationId { get; set; }
        public string CompanyNumber { get; set; }
        public string DateAdded { get; set; }
        public string DirectDepositThirdParty { get; set; }
        public string EmailAddress { get; set; }
        public string EmployeeId { get; set; }
        public string EmployeeNumber { get; set; }
        public string EthnicityId { get; set; }
        public string FirstName { get; set; }
        public string GenderId { get; set; }
        public string HireDate { get; set; }
        public string IsSupervisor { get; set; }
        public string LastName { get; set; }
        public string LocationId { get; set; }
        public string MiddleName { get; set; }
        public string Notes { get; set; }
        public string PartialSSN { get; set; }
        public string PayCheckDistributionType { get; set; }
        public string PayCheckFrequencyId { get; set; }
        public string PayRate { get; set; }
        public string Phone1 { get; set; }
        public string Phone1Description { get; set; }
        public string Phone1Extension { get; set; }
        public string Phone2 { get; set; }
        public string Phone2Description { get; set; }
        public string Phone2Extension { get; set; }
        public string Phone3 { get; set; }
        public string Phone3Description { get; set; }
        public string Phone3Extension { get; set; }
        public string PrimaryJob { get; set; }
        public string SecurityLevel { get; set; }
        public string StatusDescription { get; set; }
        public string StatusId { get; set; }
        public string SupervisorDescription { get; set; }
        public string SupervisorId { get; set; }
        public string Title { get; set; }
        public string TitleId { get; set; }
        public string TypeDescription { get; set; }
        public string TypeId { get; set; }
        public string UserName { get; set; }

        public string ToCSV()
        {
            //CSV Format
            // AccrualTypeId,BirthDate,ClassificationId,CompanyNumber,DateAdded,DirectDepositThirdParty,EmailAddress,EmployeeId,EmployeeNumber,EthnicityId,FirstName,GenderId,HireDate,IsSupervisor,LastName,LocationId,MiddleName,Notes,PartialSSN,PayCheckDistributionType,PayCheckFrequencyId,PayRate,Phone1,Phone1Description,Phone1Extension,Phone2,Phone2Description,Phone2Extension,Phone3,Phone3Description,Phone3Extension,PrimaryJob,SecurityLevel,StatusDescription,StatusId,SupervisorDescription,SupervisorId,Title,TitleId,TypeDescription,TypeId,UserName
            StringBuilder sb = new StringBuilder();
            string ret = string.Empty;

            sb.Append(AccrualTypeId);
            sb.Append(",");
            sb.Append(BirthDate);
            sb.Append(",");
            sb.Append(ClassificationId);
            sb.Append(",");
            sb.Append(CompanyNumber);
            sb.Append(",");
            sb.Append(DateAdded);
            sb.Append(",");
            sb.Append(DirectDepositThirdParty);
            sb.Append(",");
            sb.Append(EmailAddress);
            sb.Append(",");
            sb.Append(EmployeeId);
            sb.Append(",");
            sb.Append(EmployeeNumber);
            sb.Append(",");
            sb.Append(EthnicityId);
            sb.Append(",");
            sb.Append(FirstName); 
            sb.Append(",");
            sb.Append(GenderId);
            sb.Append(",");
            sb.Append(HireDate);
            sb.Append(",");
            sb.Append(IsSupervisor);
            sb.Append(",");
            sb.Append(LastName);
            sb.Append(",");
            sb.Append(LocationId);
            sb.Append(",");
            sb.Append(MiddleName);
            sb.Append(",");
            sb.Append(Notes);
            sb.Append(",");
            sb.Append(PartialSSN);
            sb.Append(",");
            sb.Append(PayCheckDistributionType);
            sb.Append(",");
            sb.Append(PayCheckFrequencyId);
            sb.Append(",");
            sb.Append(PayRate);
            sb.Append(",");
            sb.Append(Phone1);
            sb.Append(",");
            sb.Append(Phone1Description);
            sb.Append(",");
            sb.Append(Phone1Extension);
            sb.Append(",");
            sb.Append(Phone2);
            sb.Append(",");
            sb.Append(Phone2Description);
            sb.Append(",");
            sb.Append(Phone2Extension);
            sb.Append(",");
            sb.Append(Phone3);
            sb.Append(",");
            sb.Append(Phone3Description);
            sb.Append(",");
            sb.Append(Phone3Extension);
            sb.Append(",");
            sb.Append(PrimaryJob);
            sb.Append(",");
            sb.Append(SecurityLevel);
            sb.Append(",");
            sb.Append(StatusDescription);
            sb.Append(",");
            sb.Append(StatusId);
            sb.Append(",");
            sb.Append(SupervisorDescription);
            sb.Append(",");
            sb.Append(SupervisorId);
            sb.Append(",");
            sb.Append(Title);
            sb.Append(",");
            sb.Append(TitleId);
            sb.Append(",");
            sb.Append(TypeDescription);
            sb.Append(",");
            sb.Append(TypeId);
            sb.Append(",");
            sb.Append(UserName);
            sb.Append("\r\n");

            ret = sb.ToString();
            
            sb.Clear();
            sb = null;

            return ret;
        }
    }
}
