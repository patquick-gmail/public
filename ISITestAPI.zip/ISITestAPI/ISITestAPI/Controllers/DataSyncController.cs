using ISITestAPI.Models;
using ISITestAPI.Utils;

using Microsoft.AspNetCore.Mvc;
using System.Reflection.PortableExecutable;
using System.Text.Json;


namespace ISITestAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DataSyncController : ControllerBase
    {       
        private readonly ILogger<DataSyncController> _logger;

        public DataSyncController(ILogger<DataSyncController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetDataSync")]
        public IEnumerable<string> Get()
        {
            
            //call api to get json
            //load json into objects
            //perform mappings
            //return WinTeam csv
            List<PaycomEmployee> payComEmployees = null;
            List<WinTeamEmployee> winTeamEmployees = null;
            string json = string.Empty;
            string[] ret = null;

            try
            {
                json = Utils.Utils.GetPaycomJSON(false);
                if (!string.IsNullOrWhiteSpace(json))
                {
                    payComEmployees = JsonSerializer.Deserialize<List<PaycomEmployee>>(json);
                    winTeamEmployees = Utils.Utils.MapPaycomEmployeesToWinTeamEmployees(payComEmployees);
                    ret = Utils.Utils.WinTeamEmployeesToCSV(winTeamEmployees);

                }

                else 
                {
                    throw new Exception("Paycom employee JSON is empty");
                
                }


            }

            catch (Exception ex)
            {
                if (_logger.IsEnabled(LogLevel.Error)) _logger.LogError(ex, "DataSyncController.Get...Errored..." + ex.Message);
                throw;
            }

            finally
            {
               

                if (_logger.IsEnabled(LogLevel.Information)) _logger.LogInformation("DataSyncController.Get...Ending");
            }

            return ret;

            
        }
    }
}
