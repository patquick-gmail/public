﻿using ISITestAPI.Models;
using System.Text;

namespace ISITestAPI.Utils
{
    public static class Utils
    {
        public static List<PaycomWinTeamLocationMapping> PaycomWinTeamLocationMappings { get; set; }

        static Utils()
        {
            PaycomWinTeamLocationMappings = new List<PaycomWinTeamLocationMapping>();
        }

        public static string GetPaycomJSON(bool callAPI)
        {
            string ret = string.Empty;

            if (callAPI)
            {
                //TODO:  Call the api here
            }

            else
            {
                string pathFileName = AppContext.BaseDirectory + "DataFiles\\FromPaycomAPI.json";
                string fileData = string.Empty;

                if (File.Exists(pathFileName))
                {
                    fileData = File.ReadAllText(pathFileName);
                    if (fileData != string.Empty)
                    {
                        ret = fileData;
                    }
                }
            }

            return ret;
        }

        public static List<WinTeamEmployee> MapPaycomEmployeesToWinTeamEmployees (List<PaycomEmployee> employees)
        {
            List<WinTeamEmployee> ret = null;
            WinTeamEmployee winTeamEmployee = null;

            if((employees != null) && (employees.Count > 0))
            {
                ret = new List<WinTeamEmployee> ();

                foreach (PaycomEmployee employee in employees) 
                {
                    winTeamEmployee = MapPaycomEmployeeToWinTeamEmployee(employee);

                    ret.Add(winTeamEmployee);
                }

            }

            return ret;
        }

        public static WinTeamEmployee MapPaycomEmployeeToWinTeamEmployee(PaycomEmployee employee)
        {
            WinTeamEmployee ret = null;
            
            if (employee != null)
            {
                ret = new WinTeamEmployee();

                ret.BirthDate = employee.birth_date;
                ret.DateAdded = employee.employee_added;
                ret.EmployeeNumber = employee.clocksequencenumber.ToString();
                ret.FirstName = employee.firstname;
                ret.GenderId = employee.gender.ToString();
                ret.LastName = employee.lastname;
                ret.LocationId = GetWinTeamLocationId(employee);                
                ret.PartialSSN = employee.ss_number.ToString();
                ret.PayRate = employee.last_pay_rate.ToString();                
                ret.Phone1 = employee.primary_phone.ToString();
                ret.Phone1Description = employee.primary_phone_type.ToString();
                ret.StatusDescription = employee.employee_status;
                ret.SupervisorDescription = employee.supervisor_primary;
                //ret.SupervisorId = employee.supervisor_primary_code;
                ret.Title = employee.business_title;

            }

            return ret;
        }

        public static string GetWinTeamLocationId(PaycomEmployee employee)
        {
            string ret = string.Empty;

            if ((PaycomWinTeamLocationMappings == null) || (PaycomWinTeamLocationMappings.Count < 1))
            {
                PaycomWinTeamLocationMappings = LoadPaycomWinTeamLocationMappings(); 
            }

            if ((PaycomWinTeamLocationMappings != null) && (PaycomWinTeamLocationMappings.Count > 0)) 
            { 
                var mapping = from p in PaycomWinTeamLocationMappings 
                              where p.PaycomCat1 == employee.cat1.ToString() && p.PaycomCat2 == employee.cat2
                              select p.WinTeamLocationId;

                if (mapping != null)
                {
                    ret = mapping.FirstOrDefault();
                }
            }

            return ret;
        }

        public static List<PaycomWinTeamLocationMapping> LoadPaycomWinTeamLocationMappings()
        {
            List<PaycomWinTeamLocationMapping> ret = null;
            if (PaycomWinTeamLocationMappings != null)
            {
                PaycomWinTeamLocationMappings.Clear();
            }

            //TODO:  Load the path file name from the config file
            string pathFileName = AppContext.BaseDirectory + "DataFiles\\LocationMapping.csv";
            string fileData = string.Empty;

            if (File.Exists(pathFileName))
            {
                fileData = File.ReadAllText(pathFileName);
                if (fileData != string.Empty)
                {
                    string[] strings = fileData.Split("\r\n");
                    if (strings.Length > 0)
                    {
                        ret = new List<PaycomWinTeamLocationMapping>();

                        for (int x = 0; x < strings.Length; x++)
                        {
                            string str = strings[x];
                            if (str != string.Empty)
                            {
                                PaycomWinTeamLocationMapping mapping = new PaycomWinTeamLocationMapping(str);
                                ret.Add(mapping);
                            }

                        }

                    }

                }
            }

            PaycomWinTeamLocationMappings = ret;

            return ret;
            
        }

        public static string[] WinTeamEmployeesToCSV(List<WinTeamEmployee> employees)
        {
            StringBuilder sb = null;
            string[] ret = null;
            string retVal = string.Empty;

            if((employees != null) && (employees.Count > 0))
            {
                sb = new StringBuilder();

                foreach (WinTeamEmployee employee in employees)
                {
                    sb.Append(employee.ToCSV());                    
                }

                retVal = sb.ToString();

                sb.Clear();
                sb = null;

                string pathFileName = AppContext.BaseDirectory + "DataFiles\\ToWinTeam.csv";
                if (File.Exists(pathFileName))
                {
                    File.Move(pathFileName, pathFileName + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                }

                File.WriteAllText(pathFileName, retVal);

                ret = new string[] { pathFileName, retVal };
            }

            return ret;
        }
    }
}
